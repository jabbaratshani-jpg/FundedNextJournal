package com.ali.fundednextjournal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("journal", MODE_PRIVATE)
        setContent {
            MaterialTheme {
                var challenges by remember { mutableStateOf(loadChallenges(prefs.getString("data", "[]") ?: "[]")) }
                var selectedId by remember { mutableStateOf<String?>(null) }
                var newName by remember { mutableStateOf("") }
                var firm by remember { mutableStateOf("FundedNext") }
                var accountSize by remember { mutableStateOf("6000") }
                var date by remember { mutableStateOf("") }
                var symbol by remember { mutableStateOf("XAUUSD") }
                var direction by remember { mutableStateOf("Buy") }
                var result by remember { mutableStateOf("0") }
                var reason by remember { mutableStateOf("") }
                var error by remember { mutableStateOf("") }
                fun save() { prefs.edit().putString("data", serialize(challenges)).apply() }
                val selected = challenges.find { it.id == selectedId }
                Scaffold(topBar = { TopAppBar(title = { Text("ژورنال معاملات") }) }) { pad ->
                    LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        item { Text("مدیریت چند چالش", style = MaterialTheme.typography.headlineSmall) }
                        item { OutlinedTextField(newName, { newName = it }, label = { Text("نام چالش جدید") }, modifier = Modifier.fillMaxWidth()) }
                        item { OutlinedTextField(firm, { firm = it }, label = { Text("شرکت پراپ") }, modifier = Modifier.fillMaxWidth()) }
                        item { OutlinedTextField(accountSize, { accountSize = it }, label = { Text("سرمایه اولیه حساب ($)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth()) }
                        item { Button(onClick = {
                            val amount = accountSize.toDoubleOrNull()
                            if (newName.isBlank() || amount == null || amount <= 0) error = "نام چالش و سرمایه معتبر وارد کن"
                            else { val c = Challenge(System.currentTimeMillis().toString(), newName.trim(), firm.trim(), amount, mutableListOf()); challenges = challenges + c; selectedId = c.id; newName = ""; error = ""; save() }
                        }, modifier = Modifier.fillMaxWidth()) { Text("افزودن چالش") } }
                        if (error.isNotBlank()) item { Text(error, color = MaterialTheme.colorScheme.error) }
                        item { Divider(); Text("چالش‌های من", style = MaterialTheme.typography.titleLarge) }
                        items(challenges, key = { it.id }) { c ->
                            Card(Modifier.fillMaxWidth(), onClick = { selectedId = c.id }) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(c.name, style = MaterialTheme.typography.titleMedium)
                                    Text("${c.firm} • سرمایه: $${c.startBalance.toInt()} • معاملات: ${c.trades.size}")
                                    Text("سود/زیان ثبت‌شده: $${c.trades.sumOf { it.pnl }}")
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        TextButton(onClick = { selectedId = c.id }) { Text(if (selectedId == c.id) "انتخاب‌شده" else "انتخاب") }
                                        TextButton(onClick = { challenges = challenges.filterNot { it.id == c.id }; if (selectedId == c.id) selectedId = null; save() }) { Text("حذف") }
                                    }
                                }
                            }
                        }
                        if (selected != null) {
                            item { Divider(); Text("ثبت معامله: ${selected.name}", style = MaterialTheme.typography.titleLarge) }
                            item { OutlinedTextField(date, { date = it }, label = { Text("تاریخ معامله (مثلاً 1405/07/29)") }, modifier = Modifier.fillMaxWidth()) }
                            item { OutlinedTextField(symbol, { symbol = it }, label = { Text("نماد") }, modifier = Modifier.fillMaxWidth()) }
                            item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(selected = direction == "Buy", onClick = { direction = "Buy" }, label = { Text("Buy") }); FilterChip(selected = direction == "Sell", onClick = { direction = "Sell" }, label = { Text("Sell") }) } }
                            item { OutlinedTextField(result, { result = it }, label = { Text("سود/زیان دلار (ضرر منفی، مثال -100)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth()) }
                            item { OutlinedTextField(reason, { reason = it }, label = { Text("دلیل ورود / خطا / یادداشت") }, minLines = 2, modifier = Modifier.fillMaxWidth()) }
                            item { Button(onClick = {
                                val pnl = result.toDoubleOrNull()
                                if (pnl == null) error = "سود/زیان را به عدد وارد کن"
                                else { val updated = selected.copy(trades = (selected.trades + Trade(date, symbol, direction, pnl, reason)).toMutableList()); challenges = challenges.map { if (it.id == selected.id) updated else it }; save(); date = ""; result = "0"; reason = ""; error = "" }
                            }, modifier = Modifier.fillMaxWidth()) { Text("ذخیره معامله") } }
                            if (selected.trades.isNotEmpty()) item { Text("معاملات ثبت‌شده", style = MaterialTheme.typography.titleMedium) }
                            items(selected.trades.reversed()) { t -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(10.dp)) { Text("${t.date} • ${t.symbol} • ${t.direction}"); Text("سود/زیان: $${t.pnl}"); if (t.note.isNotBlank()) Text(t.note) } } }
                        }
                        item { Text("اطلاعات روی همین گوشی ذخیره می‌شود. برای نگهداری سوابق، از اطلاعات گوشی نسخه پشتیبان داشته باش.", style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
        }
    }
}

data class Trade(val date: String, val symbol: String, val direction: String, val pnl: Double, val note: String)
data class Challenge(val id: String, val name: String, val firm: String, val startBalance: Double, val trades: MutableList<Trade>)

fun serialize(challenges: List<Challenge>): String {
    val root = JSONArray()
    challenges.forEach { c ->
        val obj = JSONObject().put("id", c.id).put("name", c.name).put("firm", c.firm).put("balance", c.startBalance)
        val trades = JSONArray(); c.trades.forEach { t -> trades.put(JSONObject().put("date", t.date).put("symbol", t.symbol).put("direction", t.direction).put("pnl", t.pnl).put("note", t.note)) }
        obj.put("trades", trades); root.put(obj)
    }
    return root.toString()
}
fun loadChallenges(raw: String): List<Challenge> = try {
    val root = JSONArray(raw); (0 until root.length()).map { i ->
        val o = root.getJSONObject(i); val arr = o.optJSONArray("trades") ?: JSONArray(); val ts = (0 until arr.length()).map { j -> val t = arr.getJSONObject(j); Trade(t.optString("date"), t.optString("symbol"), t.optString("direction"), t.optDouble("pnl"), t.optString("note")) }.toMutableList()
        Challenge(o.optString("id"), o.optString("name"), o.optString("firm"), o.optDouble("balance"), ts)
    }
} catch (_: Exception) { emptyList() }
